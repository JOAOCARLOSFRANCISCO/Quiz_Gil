'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, BookOpen, ClipboardList, Zap, Target, Award, ListOrdered, Globe, ShieldCheck, Clock, ChevronDown, Check } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { cn } from '@/lib/utils';
import { getRanking } from '@/lib/quizEngine';
import { translations, Language } from '@/lib/i18n';

export default function HomePage() {
  const router = useRouter();
  const [selectedMode, setSelectedMode] = useState<'treino' | 'simulado' | 'revisao' | 'exame'>('treino');
  const [questionCount, setQuestionCount] = useState<number>(10);
  const [examTime, setExamTime] = useState<number>(180);
  const [lang, setLang] = useState<Language>('pt');
  const [mounted, setMounted] = useState(false);
  const configRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const frame = requestAnimationFrame(() => {
      setMounted(true);
      const savedLang = localStorage.getItem('pmp_lang') as Language;
      if (savedLang && ['pt', 'en', 'es'].includes(savedLang)) {
        setLang(savedLang);
      }
    });
    return () => cancelAnimationFrame(frame);
  }, []);

  const t = translations[lang];
  const ranking = mounted ? getRanking() : [];

  const modes = [
    { id: 'treino', name: t.modes.treino, icon: Zap, desc: t.modes.treinoDesc, color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-100' },
    { id: 'simulado', name: t.modes.simulado, icon: ClipboardList, desc: t.modes.simuladoDesc, color: 'text-rose-500', bg: 'bg-rose-50', border: 'border-rose-100' },
    { id: 'exame', name: t.modes.exame, icon: ShieldCheck, desc: t.modes.exameDesc, color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100' },
    { id: 'revisao', name: t.modes.revisao, icon: BookOpen, desc: t.modes.revisaoDesc, color: 'text-indigo-500', bg: 'bg-indigo-50', border: 'border-indigo-100' },
  ];

  const counts = useMemo(() => 
    selectedMode === 'exame' ? [60, 100, 150, 180] : [10, 20, 50, 100]
  , [selectedMode]);

  const handleModeChange = (mode: 'treino' | 'simulado' | 'revisao' | 'exame') => {
    setSelectedMode(mode);
    if (mode === 'exame') {
      setQuestionCount(180);
    } else {
      setQuestionCount(10);
    }
  };

  const times = [60, 120, 180, 230];

  const handleStart = () => {
    let url = `/quiz?mode=${selectedMode}&count=${questionCount}&lang=${lang}`;
    if (selectedMode === 'exame') {
      url += `&time=${examTime}`;
    }
    router.push(url);
  };

  const toggleLang = () => {
    const next: Record<Language, Language> = { pt: 'en', en: 'es', es: 'pt' };
    const newLang = next[lang];
    setLang(newLang);
    localStorage.setItem('pmp_lang', newLang);
  };

  const scrollToConfig = () => {
    configRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <main className="min-h-screen bg-white text-slate-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      {/* Language Switcher */}
      <div className="fixed top-6 right-6 z-50">
        <button
          onClick={toggleLang}
          className="flex items-center gap-2 bg-white/40 backdrop-blur-xl px-5 py-2.5 rounded-full shadow-[0_8px_32px_rgba(0,0,0,0.05)] border border-white/20 font-black text-slate-700 hover:bg-white/60 transition-all active:scale-95 group"
        >
          <Globe className="w-4 h-4 text-indigo-500 group-hover:rotate-12 transition-transform" />
          <span className="text-xs tracking-widest">{lang.toUpperCase()}</span>
        </button>
      </div>

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 px-6 overflow-hidden">
        {/* Abstract Background Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none -z-10">
          <motion.div 
            animate={{ 
              scale: [1, 1.3, 1],
              x: [0, 50, 0],
              y: [0, 30, 0],
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-[-15%] left-[-15%] w-[60%] h-[60%] bg-indigo-200/20 rounded-full blur-[140px]" 
          />
          <motion.div 
            animate={{ 
              scale: [1.3, 1, 1.3],
              x: [0, -50, 0],
              y: [0, -30, 0],
            }}
            transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
            className="absolute bottom-[-15%] right-[-15%] w-[60%] h-[60%] bg-emerald-200/20 rounded-full blur-[140px]" 
          />
          <motion.div 
            animate={{ 
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[80%] bg-violet-100/10 rounded-full blur-[160px]" 
          />
        </div>

        <div className="max-w-5xl mx-auto text-center space-y-10">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center gap-2 px-5 py-2 bg-white/80 backdrop-blur-sm text-indigo-600 rounded-full text-[10px] font-black tracking-[0.3em] uppercase border border-indigo-100 shadow-xl shadow-indigo-500/5"
          >
            <Award className="w-4 h-4" />
            PMP Mastery v2.5 • AI Powered
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            className="text-7xl md:text-[10rem] font-black tracking-tighter text-slate-900 leading-[0.8] drop-shadow-sm"
          >
            {(t.hero as any).title}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 1 }}
            className="text-xl md:text-4xl text-slate-500 font-medium max-w-4xl mx-auto leading-[1.1] tracking-tight"
          >
            {(t.hero as any).subtitle}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-8"
          >
            <button
              onClick={scrollToConfig}
              className="px-14 py-7 bg-indigo-600 text-white rounded-[2.5rem] font-black text-2xl shadow-[0_25px_60px_rgba(79,70,229,0.4)] hover:bg-indigo-700 hover:scale-105 active:scale-95 transition-all flex items-center gap-4 group"
            >
              {(t.hero as any).cta}
              <ChevronDown className="w-7 h-7 group-hover:translate-y-1 transition-transform" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* Game Modes Grid */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {modes.map((mode, idx) => (
            <motion.button
              key={mode.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + idx * 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              onClick={() => {
                handleModeChange(mode.id as any);
                scrollToConfig();
              }}
              className={cn(
                "group relative p-10 rounded-[4rem] border-2 transition-all text-left overflow-hidden flex flex-col h-full",
                selectedMode === mode.id 
                  ? "border-indigo-600 bg-white shadow-[0_40px_80px_rgba(79,70,229,0.2)] ring-8 ring-indigo-50/50" 
                  : "border-slate-100 bg-white hover:border-indigo-300 hover:shadow-3xl hover:shadow-slate-200/50"
              )}
            >
              <div className={cn(
                "w-20 h-20 rounded-3xl flex items-center justify-center mb-10 transition-all group-hover:scale-110 group-hover:rotate-12 group-hover:shadow-lg",
                mode.bg, mode.color
              )}>
                <mode.icon className="w-10 h-10" />
              </div>
              
              <div className="flex-1 space-y-4">
                <div className="flex items-center gap-2">
                  <h3 className="text-3xl font-black text-slate-900 leading-none">{mode.name}</h3>
                  {mode.id === 'exame' && (
                    <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[8px] font-black rounded-md uppercase tracking-widest">Real</span>
                  )}
                </div>
                <p className="text-slate-500 font-medium leading-relaxed text-base opacity-80 group-hover:opacity-100 transition-opacity">{mode.desc}</p>
              </div>

              {selectedMode === mode.id && (
                <div className="absolute top-10 right-10">
                  <motion.div 
                    initial={{ scale: 0, rotate: -45 }}
                    animate={{ scale: 1, rotate: 0 }}
                    className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center shadow-xl shadow-indigo-300"
                  >
                    <Check className="w-6 h-6 text-white stroke-[3]" />
                  </motion.div>
                </div>
              )}
            </motion.button>
          ))}
        </div>
      </section>

      {/* Configuration Section */}
      <section ref={configRef} className="max-w-4xl mx-auto px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-slate-50 rounded-[3rem] p-10 md:p-16 border border-slate-100 shadow-sm"
        >
          <div className="flex flex-col md:flex-row gap-12">
            <div className="flex-1 space-y-10">
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
                    <Target className="w-5 h-5 text-white" />
                  </div>
                  <h2 className="text-2xl font-black text-slate-900">{t.config.title}</h2>
                </div>

                {/* Question Count Toggle */}
                <div className="space-y-4">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{t.config.questionsLabel}</label>
                  <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-inner">
                    {counts.map((count) => (
                      <button
                        key={count}
                        onClick={() => setQuestionCount(count)}
                        className={cn(
                          "flex-1 py-3 rounded-xl font-black text-sm transition-all",
                          questionCount === count
                            ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200"
                            : "text-slate-400 hover:text-slate-600"
                        )}
                      >
                        {count}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Time Selection (Only for Exam Mode) */}
                <AnimatePresence mode="wait">
                  {selectedMode === 'exame' && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="space-y-4"
                    >
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {t.config.timeLabel}
                      </label>
                      <div className="flex bg-white p-1.5 rounded-2xl border border-slate-200 shadow-inner">
                        {times.map((time) => (
                          <button
                            key={time}
                            onClick={() => setExamTime(time)}
                            className={cn(
                              "flex-1 py-3 rounded-xl font-black text-sm transition-all",
                              examTime === time
                                ? "bg-indigo-600 text-white shadow-lg shadow-indigo-200"
                                : "text-slate-400 hover:text-slate-600"
                            )}
                          >
                            {time}m
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button
                onClick={handleStart}
                className="w-full bg-slate-900 text-white py-6 rounded-3xl font-black text-xl flex items-center justify-center gap-4 hover:bg-slate-800 hover:scale-[1.02] active:scale-95 transition-all shadow-2xl shadow-slate-200 group"
              >
                {t.config.startButton}
                <Play className="w-6 h-6 fill-current group-hover:translate-x-1 transition-transform" />
              </button>
            </div>

            {/* Ranking Sidebar */}
            <div className="md:w-72 space-y-6">
              <div className="flex items-center gap-2 text-slate-400">
                <ListOrdered className="w-4 h-4" />
                <span className="text-[10px] font-black uppercase tracking-[0.2em]">{t.hero.hallOfFame}</span>
              </div>
              
              <div className="space-y-3">
                {ranking.length > 0 ? (
                  ranking.slice(0, 3).map((entry, i) => (
                    <div key={i} className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-100 shadow-sm transition-transform hover:scale-105">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-8 h-8 rounded-lg flex items-center justify-center font-black text-xs",
                          i === 0 ? "bg-amber-100 text-amber-600" : 
                          i === 1 ? "bg-slate-100 text-slate-600" : 
                          "bg-orange-100 text-orange-600"
                        )}>
                          {i + 1}
                        </div>
                        <span className="text-sm font-bold text-slate-700">{entry.name}</span>
                      </div>
                      <span className="text-sm font-black text-indigo-600">{entry.xp} XP</span>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center bg-white rounded-3xl border border-dashed border-slate-200">
                    <p className="text-xs font-bold text-slate-300 italic">Nenhum recorde ainda</p>
                  </div>
                )}
              </div>

              {/* Stats Summary */}
              <div className="grid grid-cols-2 gap-3 pt-4">
                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                  <div className="text-xl font-black text-slate-900">400+</div>
                  <div className="text-[8px] text-slate-400 font-black uppercase tracking-widest">{t.hero.statsQuestions}</div>
                </div>
                <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                  <div className="text-xl font-black text-slate-900">100%</div>
                  <div className="text-[8px] text-slate-400 font-black uppercase tracking-widest">{t.hero.statsFocus}</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-12 text-center">
        <p className="text-slate-400 text-xs font-bold tracking-widest uppercase">
          © 2026 PMP Mastery • Professional Exam Simulator
        </p>
      </footer>
    </main>
  );
}
