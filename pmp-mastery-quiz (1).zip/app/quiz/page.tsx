'use client';

import { useState, useEffect, Suspense, useCallback, useMemo, useRef } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, Zap, Award, LogOut, Clock, List, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Question } from '@/lib/questions';
import { 
  getInitialState, 
  calculateXP, 
  QuizState, 
  QuizMode,
  saveToRanking
} from '@/lib/quizEngine';
import { 
  generateExam, 
  saveExamProgress, 
  loadExamProgress, 
  clearExamProgress,
  calculateExamResults
} from '@/lib/examEngine';
import { translations, Language } from '@/lib/i18n';
import QuizCard from '@/components/QuizCard';
import ProgressBar from '@/components/ProgressBar';
import ResultScreen from '@/components/ResultScreen';
import AudioPlayer from '@/components/AudioPlayer';
import GlobalTimer from '@/components/GlobalTimer';
import { Heart } from 'lucide-react';

function QuizContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  
  const mode = (searchParams.get('mode') as QuizMode) || 'treino';
  const count = parseInt(searchParams.get('count') || '10');
  const timeLimit = parseInt(searchParams.get('time') || '180');
  const lang = (searchParams.get('lang') as Language) || 'pt';
  const t = translations[lang];

  const [state, setState] = useState<QuizState | null>(null);
  const [isChanging, setIsChanging] = useState(false);
  const [showQuestionList, setShowQuestionList] = useState(false);
  const savedRef = useRef(false);

  // Initialize or Load State
  useEffect(() => {
    const init = () => {
      if (mode === 'exame') {
        const saved = loadExamProgress();
        if (saved && confirm(t.quiz.resumeConfirm)) {
          setState(saved);
        } else {
          clearExamProgress();
          const examState = generateExam(count, timeLimit);
          setState(examState);
        }
      } else {
        setState(getInitialState(mode, count));
      }
    };
    
    // Use a small delay to avoid synchronous setState in effect
    const timer = setTimeout(init, 0);
    return () => clearTimeout(timer);
  }, [mode, count, timeLimit, t.quiz.resumeConfirm]);

  // Auto-save progress for Exam Mode
  useEffect(() => {
    if (mode === 'exame' && state && !state.isFinished) {
      saveExamProgress(state);
    }
  }, [state, mode]);

  const handleExit = () => {
    if (confirm(t.quiz.exitConfirm)) {
      if (mode === 'exame') clearExamProgress();
      router.push('/');
    }
  };

  const handleAnswer = useCallback((selectedOption: string, isCorrect: boolean) => {
    if (!state) return;
    
    setState(prev => {
      if (!prev) return null;
      
      const newAnswers = [...prev.answers];
      const existingAnswerIndex = newAnswers.findIndex(a => a.questionId === prev.questions[prev.currentQuestionIndex].id);
      
      const answerData = { 
        questionId: prev.questions[prev.currentQuestionIndex].id, 
        selectedOption, 
        isCorrect 
      };

      if (existingAnswerIndex >= 0) {
        newAnswers[existingAnswerIndex] = answerData;
      } else {
        newAnswers.push(answerData);
      }

      const xpGained = calculateXP(isCorrect, prev.questions[prev.currentQuestionIndex].difficulty);
      const newLives = isCorrect ? prev.lives : Math.max(0, prev.lives - 1);
      
      // In Exam Mode, we don't finish on lives = 0, we just keep going
      const isGameOver = mode !== 'exame' && newLives === 0;

      return {
        ...prev,
        score: isCorrect ? prev.score + 1 : prev.score,
        xp: prev.xp + xpGained,
        answers: newAnswers,
        lives: newLives,
        level: Math.floor((prev.xp + xpGained) / 100) + 1,
        isFinished: isGameOver
      };
    });
  }, [mode, state]);

  const handleNext = useCallback(() => {
    if (!state) return;
    setIsChanging(true);
    setTimeout(() => {
      setState(prev => {
        if (!prev) return null;
        const isLastQuestion = prev.currentQuestionIndex + 1 === prev.questionCount;
        if (!isLastQuestion) {
          return {
            ...prev,
            currentQuestionIndex: prev.currentQuestionIndex + 1
          };
        } else {
          if (mode === 'exame') {
            clearExamProgress();
          }
          return { ...prev, isFinished: true };
        }
      });
      setIsChanging(false);
    }, 300);
  }, [mode, state]);

  const handlePrev = useCallback(() => {
    if (!state || state.currentQuestionIndex === 0) return;
    setIsChanging(true);
    setTimeout(() => {
      setState(prev => {
        if (!prev) return null;
        return {
          ...prev,
          currentQuestionIndex: prev.currentQuestionIndex - 1
        };
      });
      setIsChanging(false);
    }, 300);
  }, [state]);

  const handleTimeUp = useCallback(() => {
    if (mode === 'exame') {
      clearExamProgress();
      setState(prev => prev ? { ...prev, isFinished: true } : null);
    }
  }, [mode]);

  const handleTick = useCallback((secondsLeft: number) => {
    setState(prev => prev ? { ...prev, timeRemaining: secondsLeft } : null);
  }, []);

  useEffect(() => {
    if (state?.isFinished && !savedRef.current) {
      saveToRanking({
        name: 'Você',
        score: state.score,
        xp: state.xp,
        date: new Date().toLocaleDateString(lang === 'pt' ? 'pt-BR' : lang === 'es' ? 'es-ES' : 'en-US')
      });
      savedRef.current = true;
    }
  }, [state?.isFinished, state?.score, state?.xp, lang]);

  if (!state) {
    return (
      <div className="min-h-screen flex items-center justify-center font-black text-2xl text-slate-300">
        {t.quiz.loading}
      </div>
    );
  }

  if (state.isFinished) {
    const examResults = mode === 'exame' ? calculateExamResults(state) : null;
    
    return (
      <ResultScreen
        score={mode === 'exame' ? examResults!.score : state.score}
        total={mode === 'exame' ? examResults!.total : state.questionCount}
        xp={state.xp}
        level={state.level}
        answers={state.answers}
        isGameOver={mode !== 'exame' && state.lives === 0}
        examResults={examResults}
        onRestart={() => {
          router.replace(`/quiz?mode=${mode}&count=${count}&lang=${lang}&time=${timeLimit}&t=${Date.now()}`);
          window.location.reload();
        }}
        onHome={() => router.push('/')}
      />
    );
  }

  const currentQuestion = state.questions[state.currentQuestionIndex];
  const isAnswered = state.answers.some(a => a.questionId === currentQuestion.id);

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header Info */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <button
              onClick={handleExit}
              className="p-2 hover:bg-rose-100 rounded-full transition-colors mr-2 group"
              title={t.quiz.exitConfirm}
            >
              <LogOut className="w-6 h-6 text-slate-400 group-hover:text-rose-500" />
            </button>
            <AudioPlayer />
          </div>
          
          {mode === 'exame' && state.timeRemaining !== undefined && (
            <GlobalTimer 
              initialSeconds={state.timeRemaining} 
              onTimeUp={handleTimeUp}
              onTick={handleTick}
              lang={lang}
            />
          )}

          <div className="flex items-center gap-4 md:gap-6">
            {mode !== 'exame' && (
              <div className="flex items-center gap-1 bg-rose-50 px-3 py-1.5 rounded-2xl border border-rose-100 shadow-sm">
                {[...Array(3)].map((_, i) => (
                  <Heart 
                    key={i} 
                    className={cn(
                      "w-5 h-5 transition-all duration-300",
                      i < state.lives ? "text-rose-500 fill-current scale-110" : "text-slate-200"
                    )} 
                  />
                ))}
              </div>
            )}
            <div className="flex items-center gap-2 bg-white px-3 py-1.5 md:px-4 md:py-2 rounded-2xl shadow-sm border border-slate-100">
              <Zap className="w-4 h-4 text-emerald-500 fill-current" />
              <span className="font-black text-slate-900 text-sm md:text-base">{state.xp} XP</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-900 px-3 py-1.5 md:px-4 md:py-2 rounded-2xl shadow-lg">
              <Award className="w-4 h-4 text-amber-400" />
              <span className="font-black text-white text-sm md:text-base">LVL {state.level}</span>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <div className="flex justify-between items-end mb-2">
            <div>
              <h3 className="text-slate-400 text-xs font-black uppercase tracking-widest">{t.quiz.progressLabel}</h3>
              <div className="text-2xl font-black text-slate-900">
                {t.quiz.question} {state.currentQuestionIndex + 1} <span className="text-slate-300">/ {state.questionCount}</span>
              </div>
            </div>
            {mode === 'exame' && (
              <button 
                onClick={() => setShowQuestionList(!showQuestionList)}
                className="flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors font-bold text-sm"
              >
                <List className="w-4 h-4" />
                {t.quiz.questionList}
              </button>
            )}
          </div>
          <ProgressBar current={state.currentQuestionIndex + 1} total={state.questionCount} />
        </div>

        {/* Question List Overlay */}
        <AnimatePresence>
          {showQuestionList && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-3xl shadow-xl p-6 mb-8 border border-slate-100 grid grid-cols-6 md:grid-cols-10 gap-2"
            >
              {state.questions.map((_, idx) => {
                const answered = state.answers.some(a => a.questionId === state.questions[idx].id);
                const isCurrent = idx === state.currentQuestionIndex;
                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setState(prev => prev ? { ...prev, currentQuestionIndex: idx } : null);
                      setShowQuestionList(false);
                    }}
                    className={cn(
                      "w-full aspect-square rounded-lg flex items-center justify-center text-xs font-black transition-all",
                      isCurrent ? "bg-slate-900 text-white ring-4 ring-slate-100" :
                      answered ? "bg-emerald-100 text-emerald-700" : "bg-slate-50 text-slate-400 hover:bg-slate-100"
                    )}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {!isChanging && (
            <div className="space-y-6">
              <QuizCard
                key={currentQuestion.id}
                question={currentQuestion}
                onAnswer={handleAnswer}
                onNext={handleNext}
                isLast={state.currentQuestionIndex + 1 === state.questionCount}
                lives={state.lives}
                mode={mode}
                initialSelectedOption={state.answers.find(a => a.questionId === currentQuestion.id)?.selectedOption}
              />
              
              {/* Navigation Controls for Exam Mode */}
              <div className="flex justify-between items-center px-2">
                <button
                  onClick={handlePrev}
                  disabled={state.currentQuestionIndex === 0}
                  className={cn(
                    "flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all",
                    state.currentQuestionIndex === 0 
                      ? "text-slate-300 cursor-not-allowed" 
                      : "text-slate-600 hover:bg-white hover:shadow-md"
                  )}
                >
                  <ChevronLeft className="w-5 h-5" />
                  {t.quiz.prev}
                </button>

                <button
                  onClick={handleNext}
                  disabled={!isAnswered}
                  className={cn(
                    "flex items-center gap-2 px-8 py-3 rounded-xl font-black transition-all",
                    !isAnswered 
                      ? "bg-slate-100 text-slate-300 cursor-not-allowed" 
                      : "bg-emerald-500 text-white shadow-lg shadow-emerald-100 hover:bg-emerald-600"
                  )}
                >
                  {state.currentQuestionIndex + 1 === state.questionCount ? t.quiz.finish : t.quiz.next}
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}
          {isChanging && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center justify-center py-20"
            >
              <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function QuizLoading() {
  const searchParams = useSearchParams();
  const lang = (searchParams.get('lang') as Language) || 'pt';
  const t = translations[lang];
  return (
    <div className="min-h-screen flex items-center justify-center font-black text-2xl text-slate-300">
      {t.quiz.loading}
    </div>
  );
}

export default function QuizPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center font-black text-2xl text-slate-300">...</div>}>
      <QuizLoadingWrapper />
    </Suspense>
  );
}

function QuizLoadingWrapper() {
  return (
    <Suspense fallback={<QuizLoading />}>
      <QuizContent />
    </Suspense>
  );
}
