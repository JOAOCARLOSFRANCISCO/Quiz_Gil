'use client';

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { cn } from '@/lib/utils';

interface TimerProps {
  duration: number;
  isActive: boolean;
  onTimeout: () => void;
  resetKey: any;
}

export default function Timer({ duration, isActive, onTimeout, resetKey }: TimerProps) {
  const [timeLeft, setTimeLeft] = useState(duration);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive]);

  useEffect(() => {
    if (timeLeft === 0 && isActive) {
      onTimeout();
    }
  }, [timeLeft, isActive, onTimeout]);

  const percentage = (timeLeft / duration) * 100;
  
  const getColor = () => {
    if (timeLeft > 30) return 'bg-emerald-500';
    if (timeLeft > 10) return 'bg-amber-500';
    return 'bg-rose-500';
  };

  return (
    <div className="w-full space-y-2">
      <div className="flex justify-between items-end">
        <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Tempo Restante</span>
        <span className={cn(
          "text-lg font-black tabular-nums",
          timeLeft <= 10 ? "text-rose-500 animate-pulse" : "text-slate-700"
        )}>
          {timeLeft}s
        </span>
      </div>
      <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
        <motion.div
          className={cn("h-full rounded-full transition-colors duration-500", getColor())}
          initial={{ width: '100%' }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 1, ease: "linear" }}
        />
      </div>
    </div>
  );
}
