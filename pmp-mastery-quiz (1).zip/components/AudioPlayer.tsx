'use client';

import { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

// Sound effect URLs (reliable royalty-free sources)
const SFX = {
  correct: 'https://assets.mixkit.co/active_storage/sfx/2000/2000-preview.mp3',
  wrong: 'https://assets.mixkit.co/active_storage/sfx/2955/2955-preview.mp3',
  timeout: 'https://assets.mixkit.co/active_storage/sfx/1016/1016-preview.mp3',
};

export function playSFX(type: keyof typeof SFX) {
  if (typeof window === 'undefined') return;
  const audio = new Audio(SFX[type]);
  audio.volume = 0.3;
  audio.play().catch(() => {});
}

export default function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Using a reliable royalty-free focus music URL
    const audio = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-17.mp3');
    audio.loop = true;
    audio.volume = 0.1;
    audioRef.current = audio;

    // Auto-play attempt (might be blocked by browser until interaction)
    const playAudio = () => {
      audio.play().then(() => setIsPlaying(true)).catch(() => {
        console.log("Autoplay blocked, waiting for user interaction");
      });
    };

    playAudio();

    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, []);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <button
      onClick={togglePlay}
      className="p-3 bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-slate-100 hover:bg-slate-100 transition-colors group"
      title={isPlaying ? "Mudar para mudo" : "Ativar música"}
    >
      {isPlaying ? (
        <Volume2 className="w-5 h-5 text-emerald-500" />
      ) : (
        <VolumeX className="w-5 h-5 text-slate-400" />
      )}
    </button>
  );
}
