'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, Info, ArrowRight, Clock } from 'lucide-react';
import { Question } from '@/lib/questions';
import { cn } from '@/lib/utils';
import Timer from './Timer';
import { playSFX } from './AudioPlayer';

interface QuizCardProps {
  question: Question;
  onAnswer: (selectedId: string, isCorrect: boolean) => void;
  onNext: () => void;
  isLast: boolean;
  lives: number;
  mode?: 'treino' | 'simulado' | 'revisao' | 'exame';
  initialSelectedOption?: string;
}

export default function QuizCard({ 
  question, 
  onAnswer, 
  onNext, 
  isLast, 
  lives, 
  mode = 'treino',
  initialSelectedOption 
}: QuizCardProps) {
  const [selectedId, setSelectedId] = useState<string | null>(initialSelectedOption || null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isTimedOut, setIsTimedOut] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Reset state when question changes
  useEffect(() => {
    const reset = () => {
      setSelectedId(initialSelectedOption || null);
      setShowFeedback(false);
      setIsTimedOut(false);
      setIsProcessing(false);
    };
    
    const timer = setTimeout(reset, 0);
    return () => clearTimeout(timer);
  }, [question.id, initialSelectedOption]);

  const handleSelect = useCallback((id: string) => {
    if (showFeedback || isTimedOut || isProcessing || (mode !== 'exame' && lives <= 0)) return;
    
    setIsProcessing(true);
    setSelectedId(id);
    const isCorrect = id === question.correctOption;
    
    if (mode !== 'exame') {
      playSFX(isCorrect ? 'correct' : 'wrong');
      setShowFeedback(true);
    } else {
      playSFX('correct'); // Just a click sound or subtle feedback
    }
    
    onAnswer(id, isCorrect);
    setIsProcessing(false);
  }, [showFeedback, isTimedOut, isProcessing, lives, question.correctOption, onAnswer, mode]);

  const handleTimeout = useCallback(() => {
    if (mode === 'exame') return; // No per-question timeout in exam mode
    if (showFeedback || lives <= 0) return;
    setIsTimedOut(true);
    setShowFeedback(true);
    
    playSFX('timeout');
    
    onAnswer('timeout', false);
    
    // Auto-advance after 3s on timeout ONLY if still have lives
    if (lives > 1) {
      setTimeout(() => {
        onNext();
      }, 3000);
    }
  }, [showFeedback, lives, onAnswer, onNext, mode]);

  const isExam = mode === 'exame';

  return (
    <div className="w-full max-w-2xl mx-auto">
      {!isExam && (
        <div className="mb-6">
          <Timer 
            key={question.id}
            duration={60} 
            isActive={!showFeedback} 
            onTimeout={handleTimeout} 
            resetKey={question.id}
          />
        </div>
      )}

      <motion.div
        key={question.id}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="bg-white rounded-3xl shadow-xl p-6 md:p-8 border border-slate-100"
      >
        <div className="flex justify-between items-center mb-6">
          <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-xs font-semibold uppercase tracking-wider">
            {question.category}
          </span>
          <span className={cn(
            "px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider",
            question.difficulty === 'easy' ? "bg-emerald-100 text-emerald-600" :
            question.difficulty === 'medium' ? "bg-amber-100 text-amber-600" :
            "bg-rose-100 text-rose-600"
          )}>
            {question.difficulty}
          </span>
        </div>

        <h2 className="text-xl md:text-2xl font-bold text-slate-800 mb-8 leading-tight">
          {question.text}
        </h2>

        <div className="space-y-4 mb-8">
          {question.options.map((option) => {
            const isSelected = selectedId === option.id;
            const isCorrect = option.id === question.correctOption;
            const isWrong = isSelected && !isCorrect;

            return (
              <button
                key={option.id}
                id={`option-${option.id}`}
                onClick={() => handleSelect(option.id)}
                disabled={(!isExam && showFeedback) || isTimedOut}
                className={cn(
                  "w-full text-left p-4 rounded-2xl border-2 transition-all duration-200 flex items-center justify-between group",
                  !showFeedback && !isExam && "border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/30 cursor-pointer",
                  isExam && isSelected && "border-slate-900 bg-slate-900 text-white shadow-lg",
                  isExam && !isSelected && "border-slate-100 bg-slate-50 text-slate-600 hover:border-slate-200",
                  showFeedback && !isExam && isCorrect && "border-emerald-500 bg-emerald-50 text-emerald-700",
                  showFeedback && !isExam && isWrong && "border-rose-500 bg-rose-50 text-rose-700",
                  showFeedback && !isExam && !isCorrect && !isWrong && "border-slate-100 opacity-50",
                  isTimedOut && isCorrect && "border-emerald-500 bg-emerald-50 ring-2 ring-emerald-200"
                )}
              >
                <div className="flex items-center gap-4">
                  <span className={cn(
                    "w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm",
                    !showFeedback && !isSelected && "bg-slate-100 text-slate-500 group-hover:bg-emerald-500 group-hover:text-white",
                    isSelected && isExam && "bg-white/20 text-white",
                    showFeedback && !isExam && isCorrect && "bg-emerald-500 text-white",
                    showFeedback && !isExam && isWrong && "bg-rose-500 text-white",
                    showFeedback && !isExam && !isCorrect && !isWrong && "bg-slate-100 text-slate-400"
                  )}>
                    {option.id.toUpperCase()}
                  </span>
                  <span className="font-medium">{option.text}</span>
                </div>
                {!isExam && showFeedback && isCorrect && <CheckCircle2 className="w-6 h-6 text-emerald-500 shrink-0" />}
                {!isExam && showFeedback && isWrong && <XCircle className="w-6 h-6 text-rose-500 shrink-0" />}
              </button>
            );
          })}
        </div>

        <AnimatePresence>
          {showFeedback && !isExam && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-6 pt-6 border-t border-slate-100"
            >
              {isTimedOut && (
                <div className="flex items-center gap-2 text-rose-500 font-bold mb-4 bg-rose-50 p-3 rounded-xl border border-rose-100">
                  <Clock className="w-5 h-5" />
                  Tempo esgotado!
                </div>
              )}

              <div className="bg-slate-50 rounded-2xl p-4 mb-6">
                <div className="flex items-center gap-2 text-slate-800 font-bold mb-2">
                  <Info className="w-5 h-5 text-indigo-500" />
                  Coach PMP diz:
                </div>
                <p className="text-slate-600 italic leading-relaxed">
                  &quot;{question.explanation}&quot;
                </p>
              </div>

              <button
                id="next-question-btn"
                onClick={onNext}
                className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-slate-800 transition-colors shadow-lg shadow-slate-200"
              >
                {isLast || lives <= 0 ? "Ver Resultado Final" : "Próxima Pergunta"}
                <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

