'use client';

import { useEffect, useState } from 'react';
import { Clock, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { translations, Language } from '@/lib/i18n';

interface GlobalTimerProps {
  initialSeconds: number;
  onTimeUp: () => void;
  onTick: (secondsLeft: number) => void;
  lang: Language;
}

export default function GlobalTimer({ initialSeconds, onTimeUp, onTick, lang }: GlobalTimerProps) {
  const [timeLeft, setTimeLeft] = useState(initialSeconds);
  const [warning, setWarning] = useState<string | null>(null);
  const t = translations[lang].quiz;

  useEffect(() => {
    if (timeLeft <= 0) {
      onTimeUp();
      return;
    }

    const interval = setInterval(() => {
      setTimeLeft(prev => {
        const next = prev - 1;
        onTick(next);

        // Warnings
        const mins = Math.floor(next / 60);
        if (next === 30 * 60) setWarning(t.warning30);
        else if (next === 10 * 60) setWarning(t.warning10);
        else if (next === 5 * 60) setWarning(t.warning5);
        else if (next % 60 === 0) setWarning(null); // Clear warning after a min

        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [timeLeft, onTimeUp, onTick, t]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="sticky top-0 z-50 bg-slate-900 text-white py-3 px-6 shadow-xl flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Clock className="w-5 h-5 text-emerald-400" />
        <span className="text-sm font-bold uppercase tracking-widest text-slate-400">{t.timeRemaining}</span>
      </div>
      
      <div className="flex items-center gap-6">
        <AnimatePresence>
          {warning && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex items-center gap-2 bg-rose-500/20 text-rose-400 px-3 py-1 rounded-lg border border-rose-500/30"
            >
              <AlertCircle className="w-4 h-4" />
              <span className="text-xs font-bold">{warning}</span>
            </motion.div>
          )}
        </AnimatePresence>
        
        <span className="text-2xl font-black font-mono tracking-tighter text-emerald-400">
          {formatTime(timeLeft)}
        </span>
      </div>
    </div>
  );
}
