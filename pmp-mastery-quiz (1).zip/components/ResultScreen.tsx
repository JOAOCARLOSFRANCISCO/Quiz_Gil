'use client';

import { motion } from 'motion/react';
import { Trophy, Target, TrendingUp, RefreshCcw, Home, CheckCircle2, AlertCircle, Skull, ListOrdered, Users, Settings, Briefcase } from 'lucide-react';
import { getDiagnosis, getLevelName, getRanking } from '@/lib/quizEngine';
import { cn } from '@/lib/utils';
import { ExamResults } from '@/lib/examEngine';
import { Domain } from '@/lib/questions';
import { translations, Language } from '@/lib/i18n';
import { useSearchParams } from 'next/navigation';

interface ResultScreenProps {
  score: number;
  total: number;
  xp: number;
  level: number;
  answers: { questionId: number; isCorrect: boolean }[];
  isGameOver: boolean;
  examResults?: ExamResults | null;
  onRestart: () => void;
  onHome: () => void;
}

export default function ResultScreen({ 
  score, 
  total, 
  xp, 
  level, 
  answers, 
  isGameOver, 
  examResults,
  onRestart, 
  onHome 
}: ResultScreenProps) {
  const searchParams = useSearchParams();
  const lang = (searchParams.get('lang') as Language) || 'pt';
  const t = translations[lang];

  const percentage = Math.round((score / total) * 100);
  const { strengths, weaknesses } = getDiagnosis(answers);
  const ranking = getRanking();

  const isExam = !!examResults;

  const getTranslatedLevelName = (lvl: number) => {
    if (lvl < 3) return t.results.levels.beginner;
    if (lvl < 7) return t.results.levels.intermediate;
    if (lvl < 12) return t.results.levels.advanced;
    return t.results.levels.master;
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-8">
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-100"
      >
        <div className={cn(
          "p-10 text-center text-white relative overflow-hidden",
          isGameOver ? "bg-rose-900" : isExam ? "bg-emerald-900" : "bg-slate-900"
        )}>
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            {isGameOver ? (
              <Skull className="w-20 h-20 text-rose-400 mx-auto mb-4" />
            ) : (
              <Trophy className="w-20 h-20 text-amber-400 mx-auto mb-4" />
            )}
            <h1 className="text-3xl md:text-4xl font-black mb-2">
              {isGameOver ? t.results.gameOver : isExam ? t.results.examFinished : t.results.quizFinished}
            </h1>
            <p className="text-white/60 font-medium text-lg">
              {isGameOver ? t.results.gameOverDesc : t.results.quizFinishedDesc}
            </p>
          </motion.div>
          
          {/* Decorative background elements */}
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-emerald-500 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-indigo-500 rounded-full blur-3xl" />
          </div>
        </div>

        <div className="p-8 md:p-12">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-10">
            <div className="bg-slate-50 rounded-3xl p-6 text-center">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">{t.results.scoreLabel}</div>
              <div className="text-4xl font-black text-slate-900">{score} / {total}</div>
            </div>
            <div className="bg-slate-50 rounded-3xl p-6 text-center">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">{t.results.percentageLabel}</div>
              <div className="text-4xl font-black text-slate-900">{percentage}%</div>
            </div>
            <div className="bg-slate-50 rounded-3xl p-6 text-center col-span-2 md:col-span-1">
              <div className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">{t.results.xpLabel}</div>
              <div className="text-4xl font-black text-emerald-600">+{xp}</div>
            </div>
          </div>

          {/* Exam Domain Breakdown */}
          {isExam && examResults && (
            <div className="mb-10 space-y-6">
              <div className="flex items-center gap-2 mb-4 text-slate-800">
                <Target className="w-5 h-5 text-emerald-500" />
                <h2 className="font-bold text-xl">{t.results.domainPerformance}</h2>
              </div>
              
          <div className="grid gap-4">
            {[
              { id: 'Pessoas', key: 'pessoas', icon: Users, color: 'text-blue-500', bg: 'bg-blue-50', border: 'border-blue-100' },
              { id: 'Processos', key: 'processos', icon: Settings, color: 'text-amber-500', bg: 'bg-amber-50', border: 'border-amber-100' },
              { id: 'Ambiente de Negócios', key: 'ambiente', icon: Briefcase, color: 'text-emerald-500', bg: 'bg-emerald-50', border: 'border-emerald-100' }
            ].map(domain => {
              const perf = examResults.domainPerformance[domain.id as Domain] || { score: 0, total: 0 };
              const domainPercentage = perf.total > 0 ? Math.round((perf.score / perf.total) * 100) : 0;
              const domainName = (t.results.domains as any)[domain.key] || domain.id;
              
              return (
                <div key={domain.id} className={cn("p-5 rounded-2xl border flex items-center justify-between", domain.bg, domain.border)}>
                  <div className="flex items-center gap-4">
                    <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center bg-white shadow-sm", domain.color)}>
                      <domain.icon className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="font-bold text-slate-800">{domainName}</div>
                      <div className="text-sm text-slate-500">{perf.score} / {perf.total} {t.quiz.question.toLowerCase()}s</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={cn("text-2xl font-black", domain.color)}>{domainPercentage}%</div>
                    <div className="w-24 h-2 bg-white rounded-full mt-1 overflow-hidden">
                      <div 
                        className={cn("h-full transition-all duration-1000", domain.color.replace('text-', 'bg-'))}
                        style={{ width: `${domainPercentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
            </div>
          )}

          {/* Ranking Section */}
          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4 text-slate-800">
              <ListOrdered className="w-5 h-5 text-indigo-500" />
              <h2 className="font-bold text-xl">{t.results.rankingTitle}</h2>
            </div>
            <div className="space-y-2">
              {ranking.map((entry, i) => (
                <div key={i} className={cn(
                  "flex items-center justify-between p-4 rounded-2xl border transition-all",
                  i === 0 ? "bg-amber-50 border-amber-100 scale-[1.02] shadow-sm" : "bg-slate-50 border-slate-100"
                )}>
                  <div className="flex items-center gap-3">
                    <span className="w-6 text-center font-black text-slate-400">{i + 1}</span>
                    <span className="font-bold text-slate-700">{entry.name}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="text-xs font-bold text-slate-400">{entry.date}</span>
                    <span className="font-black text-emerald-600">{entry.xp} XP</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mb-10">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-indigo-500" />
              <h2 className="font-bold text-xl text-slate-800">{t.results.levelTitle}</h2>
            </div>
            <div className="bg-slate-900 rounded-3xl p-6 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-indigo-500 rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-lg shadow-indigo-500/20">
                  {level}
                </div>
                <div>
                  <div className="text-white font-black text-lg">{getTranslatedLevelName(level)}</div>
                  <div className="text-slate-400 text-sm font-medium">{t.results.nextLevel.replace('{xp}', '150')}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-3 text-emerald-600">
                <CheckCircle2 className="w-5 h-5" />
                <h3 className="font-bold">{t.results.strengths}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {strengths.length > 0 ? strengths.map(s => (
                  <span key={s} className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-sm font-medium border border-emerald-100">
                    {(t.results.categories as any)[s] || s}
                  </span>
                )) : <span className="text-slate-400 text-sm italic">{t.results.noStrengths}</span>}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-3 text-rose-500">
                <AlertCircle className="w-5 h-5" />
                <h3 className="font-bold">{t.results.weaknesses}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {weaknesses.length > 0 ? weaknesses.map(w => (
                  <span key={w} className="px-3 py-1 bg-rose-50 text-rose-700 rounded-full text-sm font-medium border border-rose-100">
                    {(t.results.categories as any)[w] || w}
                  </span>
                )) : <span className="text-slate-400 text-sm italic">{t.results.noWeaknesses}</span>}
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-4">
            <button
              id="restart-quiz-btn"
              onClick={onRestart}
              className="flex-1 bg-emerald-500 text-white py-5 rounded-2xl font-black text-lg flex items-center justify-center gap-2 hover:bg-emerald-600 transition-all shadow-xl shadow-emerald-200"
            >
              <RefreshCcw className="w-6 h-6" />
              {t.results.restartButton}
            </button>
            <button
              id="home-btn"
              onClick={onHome}
              className="flex-1 bg-slate-100 text-slate-600 py-5 rounded-2xl font-black text-lg flex items-center justify-center gap-2 hover:bg-slate-200 transition-all"
            >
              <Home className="w-6 h-6" />
              {t.results.homeButton}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

