import { Question, questions } from './questions';

export type QuizMode = 'treino' | 'simulado' | 'revisao' | 'exame';

export interface QuizState {
  mode: QuizMode;
  questionCount: number;
  currentQuestionIndex: number;
  score: number;
  answers: { questionId: number; selectedOption: string; isCorrect: boolean }[];
  xp: number;
  level: number;
  lives: number;
  isFinished: boolean;
  startTime: number;
  questions: Question[];
  timeRemaining?: number;
  totalTime?: number;
  preTestIds?: number[];
}

export interface RankingEntry {
  name: string;
  score: number;
  xp: number;
  date: string;
}

export function getInitialState(mode: QuizMode, count: number): QuizState {
  return {
    mode,
    questionCount: count,
    currentQuestionIndex: 0,
    score: 0,
    answers: [],
    xp: 0,
    level: 1,
    lives: 3,
    isFinished: false,
    startTime: Date.now(),
    questions: getRandomQuestions(count),
  };
}

export function saveToRanking(entry: RankingEntry) {
  if (typeof window === 'undefined') return;
  const existing = getRanking();
  
  // Avoid saving if score is 0 unless it's a real attempt
  if (entry.xp === 0 && entry.score === 0) return;

  const updated = [...existing, entry]
    .sort((a, b) => b.xp - a.xp)
    .slice(0, 10); // Keep top 10 instead of 5 for better ranking
  localStorage.setItem('pmp_ranking', JSON.stringify(updated));
}

export function getRanking(): RankingEntry[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem('pmp_ranking');
  return data ? JSON.parse(data) : [];
}

export function getRandomQuestions(count: number): Question[] {
  const shuffled = [...questions].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

export function calculateXP(isCorrect: boolean, difficulty: string): number {
  if (!isCorrect) return 5; // Small XP for effort
  const baseXP = 20;
  const multiplier = difficulty === 'hard' ? 2 : difficulty === 'medium' ? 1.5 : 1;
  return Math.round(baseXP * multiplier);
}

export function getLevelName(level: number): string {
  if (level < 3) return 'Iniciante';
  if (level < 7) return 'Intermediário';
  if (level < 12) return 'Avançado';
  return 'Mestre PMP';
}

export function getDiagnosis(answers: { questionId: number; isCorrect: boolean }[]) {
  const categories = questions.reduce((acc, q) => {
    acc[q.category] = acc[q.category] || { total: 0, correct: 0 };
    return acc;
  }, {} as Record<string, { total: 0; correct: 0 }>);

  answers.forEach(ans => {
    const q = questions.find(q => q.id === ans.questionId);
    if (q) {
      categories[q.category].total++;
      if (ans.isCorrect) categories[q.category].correct++;
    }
  });

  const strengths = Object.entries(categories)
    .filter(([_, stats]) => stats.total > 0 && (stats.correct / stats.total) >= 0.7)
    .map(([cat]) => cat);

  const weaknesses = Object.entries(categories)
    .filter(([_, stats]) => stats.total > 0 && (stats.correct / stats.total) < 0.7)
    .map(([cat]) => cat);

  return { strengths, weaknesses };
}
