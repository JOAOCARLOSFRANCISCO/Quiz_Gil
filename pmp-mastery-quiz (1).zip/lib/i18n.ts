export type Language = 'pt' | 'en' | 'es';

export const translations = {
  pt: {
    hero: {
      title: "Simulador PMP Inteligente",
      subtitle: "Treine com IA, simule o exame real e passe na certificação",
      cta: "Começar Agora",
      description: "Simulados inteligentes, gamificação e feedback de coach para acelerar sua aprovação.",
      statsQuestions: "Questões Reais",
      statsFocus: "Foco no Exame",
      hallOfFame: "Hall da Fama"
    },
    modes: {
      treino: "MODO RÁPIDO",
      treinoDesc: "10 questões rápidas para treinar em qualquer lugar.",
      simulado: "MODO PRÁTICA",
      simuladoDesc: "Sem tempo, foco em aprender com feedback detalhado.",
      revisao: "MODO REVISÃO",
      revisaoDesc: "Foque nas questões que você errou anteriormente.",
      exame: "MODO EXAME",
      exameDesc: "Foco em tempo e pressão. Simulação real do PMP."
    },
    config: {
      title: "Configuração da Missão",
      modeLabel: "Selecione o Modo",
      questionsLabel: "Quantidade de Questões",
      timeLabel: "Tempo Limite (Minutos)",
      startButton: "Começar Missão"
    },
    quiz: {
      next: "Próxima",
      prev: "Anterior",
      finish: "Finalizar Exame",
      exit: "Sair",
      exitConfirm: "Tem certeza que deseja sair? Seu progresso será perdido.",
      resumeConfirm: "Deseja continuar de onde parou?",
      timeRemaining: "Tempo Restante",
      question: "Questão",
      questionList: "Lista de Questões",
      progressLabel: "Seu Progresso",
      of: "de",
      answered: "Respondida",
      notAnswered: "Não respondida",
      warning30: "Faltam 30 minutos!",
      warning10: "Faltam 10 minutos!",
      warning5: "Faltam 5 minutos!",
      timeUp: "O tempo acabou! O exame será finalizado.",
      loading: "Carregando Missão..."
    },
    results: {
      title: "Resultado do Exame",
      gameOver: "Fim de Jogo!",
      gameOverDesc: "Você perdeu todas as vidas. Continue praticando!",
      quizFinished: "Quiz Concluído!",
      examFinished: "Exame PMP Finalizado!",
      quizFinishedDesc: "Excelente trabalho! Confira seu desempenho abaixo.",
      scoreLabel: "Pontuação",
      percentageLabel: "Taxa de Acerto",
      xpLabel: "XP Ganho",
      domainPerformance: "Desempenho por Domínio",
      rankingTitle: "Ranking Global",
      levelTitle: "Seu Progresso",
      strengths: "Pontos Fortes",
      weaknesses: "Áreas de Melhoria",
      nextLevel: "Próximo nível em {xp} XP",
      noStrengths: "Continue praticando para identificar forças.",
      noWeaknesses: "Nenhuma área crítica identificada!",
      restartButton: "Tentar Novamente",
      homeButton: "Voltar ao Início",
      levels: {
        beginner: "Iniciante",
        intermediate: "Intermediário",
        advanced: "Avançado",
        master: "Mestre PMP"
      },
      domains: {
        pessoas: "Pessoas",
        processos: "Processos",
        ambiente: "Ambiente de Negócios"
      },
      categories: {
        "Integração": "Integração",
        "Monitoramento e Controle": "Monitoramento e Controle",
        "Escopo": "Escopo",
        "Custos": "Custos",
        "Qualidade": "Qualidade",
        "Recursos": "Recursos",
        "Aquisições": "Aquisições",
        "Ética": "Ética",
        "Comunicações": "Comunicações",
        "Estratégia": "Estratégia"
      }
    }
  },
  en: {
    hero: {
      title: "Smart PMP Simulator",
      subtitle: "Train with AI, simulate the real exam, and pass the certification",
      cta: "Start Now",
      description: "Smart simulations, gamification, and coach feedback to accelerate your approval.",
      statsQuestions: "Real Questions",
      statsFocus: "Exam Focus",
      hallOfFame: "Hall of Fame"
    },
    modes: {
      treino: "QUICK MODE",
      treinoDesc: "10 quick questions to train anywhere.",
      simulado: "PRACTICE MODE",
      simuladoDesc: "No time limit, focus on learning with detailed feedback.",
      revisao: "REVIEW MODE",
      revisaoDesc: "Focus on the questions you missed previously.",
      exame: "EXAM MODE",
      exameDesc: "Focus on time and pressure. Real PMP simulation."
    },
    config: {
      title: "Mission Configuration",
      modeLabel: "Select Mode",
      questionsLabel: "Number of Questions",
      timeLabel: "Time Limit (Minutes)",
      startButton: "Start Mission"
    },
    quiz: {
      next: "Next",
      prev: "Previous",
      finish: "Finish Exam",
      exit: "Exit",
      exitConfirm: "Are you sure you want to exit? Your progress will be lost.",
      resumeConfirm: "Do you want to continue where you left off?",
      timeRemaining: "Time Remaining",
      question: "Question",
      questionList: "Question List",
      progressLabel: "Your Progress",
      of: "of",
      answered: "Answered",
      notAnswered: "Not answered",
      warning30: "30 minutes left!",
      warning10: "10 minutes left!",
      warning5: "5 minutes left!",
      timeUp: "Time is up! The exam will be finished.",
      loading: "Loading Mission..."
    },
    results: {
      title: "Exam Result",
      gameOver: "Game Over!",
      gameOverDesc: "You lost all your lives. Keep practicing!",
      quizFinished: "Quiz Finished!",
      examFinished: "PMP Exam Finished!",
      quizFinishedDesc: "Excellent work! Check your performance below.",
      scoreLabel: "Score",
      percentageLabel: "Success Rate",
      xpLabel: "XP Gained",
      domainPerformance: "Performance by Domain",
      rankingTitle: "Global Ranking",
      levelTitle: "Your Progress",
      strengths: "Strengths",
      weaknesses: "Areas for Improvement",
      nextLevel: "Next level in {xp} XP",
      noStrengths: "Keep practicing to identify strengths.",
      noWeaknesses: "No critical areas identified!",
      restartButton: "Try Again",
      homeButton: "Back to Home",
      levels: {
        beginner: "Beginner",
        intermediate: "Intermediate",
        advanced: "Advanced",
        master: "PMP Master"
      },
      domains: {
        pessoas: "People",
        processos: "Processes",
        ambiente: "Business Environment"
      },
      categories: {
        "Integração": "Integration",
        "Monitoramento e Controle": "Monitoring & Control",
        "Escopo": "Scope",
        "Custos": "Costs",
        "Qualidade": "Quality",
        "Recursos": "Resources",
        "Aquisições": "Procurement",
        "Ética": "Ethics",
        "Comunicações": "Communications",
        "Estratégia": "Strategy"
      }
    }
  },
  es: {
    hero: {
      title: "Simulador PMP Inteligente",
      subtitle: "Entrena con IA, simula el examen real y aprueba la certificación",
      cta: "Comenzar Ahora",
      description: "Simulacros inteligentes, gamificación y retroalimentación de coach para acelerar tu aprobación.",
      statsQuestions: "Preguntas Reales",
      statsFocus: "Enfoque en el Examen",
      hallOfFame: "Salón de la Fama"
    },
    modes: {
      treino: "MODO RÁPIDO",
      treinoDesc: "10 preguntas rápidas para entrenar en cualquier lugar.",
      simulado: "MODO PRÁCTICA",
      simuladoDesc: "Sin tiempo, enfoque en aprender con feedback detallado.",
      revisao: "MODO REVISIÓN",
      revisaoDesc: "Enfócate en las preguntas que fallaste anteriormente.",
      exame: "MODO EXAMEN",
      exameDesc: "Enfoque en tiempo y presión. Simulación real del PMP."
    },
    config: {
      title: "Configuración de la Misión",
      modeLabel: "Seleccionar Modo",
      questionsLabel: "Cantidad de Preguntas",
      timeLabel: "Límite de Tiempo (Minutos)",
      startButton: "Comenzar Misión"
    },
    quiz: {
      next: "Siguiente",
      prev: "Anterior",
      finish: "Finalizar Examen",
      exit: "Salir",
      exitConfirm: "¿Estás seguro de que quieres salir? Tu progreso se perderá.",
      resumeConfirm: "¿Quieres continuar donde lo dejaste?",
      timeRemaining: "Tiempo Restante",
      question: "Pregunta",
      questionList: "Lista de Preguntas",
      progressLabel: "Tu Pregreso",
      of: "de",
      answered: "Respondida",
      notAnswered: "No respondida",
      warning30: "¡Quedan 30 minutos!",
      warning10: "¡Quedan 10 minutos!",
      warning5: "¡Quedan 5 minutos!",
      timeUp: "¡El tiempo se ha acabado! El examen finalizará.",
      loading: "Cargando Misión..."
    },
    results: {
      title: "Resultado del Examen",
      gameOver: "¡Fin del Juego!",
      gameOverDesc: "Perdiste todas tus vidas. ¡Sigue practicando!",
      quizFinished: "¡Quiz Concluido!",
      examFinished: "¡Examen PMP Finalizado!",
      quizFinishedDesc: "¡Excelente trabajo! Revisa tu desempeño a continuación.",
      scoreLabel: "Puntuación",
      percentageLabel: "Tasa de Acierto",
      xpLabel: "XP Ganado",
      domainPerformance: "Desempeño por Dominio",
      rankingTitle: "Ranking Global",
      levelTitle: "Tu Progreso",
      strengths: "Puntos Fuertes",
      weaknesses: "Áreas de Mejora",
      nextLevel: "Próximo nivel en {xp} XP",
      noStrengths: "Sigue practicando para identificar fortalezas.",
      noWeaknesses: "¡No se identificaron áreas críticas!",
      restartButton: "Intentar de Nuevo",
      homeButton: "Volver al Inicio",
      levels: {
        beginner: "Principiante",
        intermediate: "Intermedio",
        advanced: "Avanzado",
        master: "Maestro PMP"
      },
      domains: {
        pessoas: "Personas",
        processos: "Procesos",
        ambiente: "Entorno Empresarial"
      },
      categories: {
        "Integração": "Integración",
        "Monitoramento e Controle": "Monitoreo y Control",
        "Escopo": "Alcance",
        "Custos": "Costos",
        "Qualidade": "Calidad",
        "Recursos": "Recursos",
        "Aquisições": "Adquisiciones",
        "Ética": "Ética",
        "Comunicações": "Comunicaciones",
        "Estratégia": "Estrategia"
      }
    }
  }
};
