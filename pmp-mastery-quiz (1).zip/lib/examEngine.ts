import { Question, questions, Domain } from './questions';
import { QuizState } from './quizEngine';

export function generateExam(count: number, totalTimeMinutes: number): QuizState {
  const preTestCount = 5;
  const realCount = count - preTestCount;

  const peopleCount = Math.round(realCount * 0.42);
  const processCount = Math.round(realCount * 0.50);
  const businessCount = realCount - peopleCount - processCount;

  const peoplePool = questions.filter(q => q.domain === 'Pessoas');
  const processPool = questions.filter(q => q.domain === 'Processos');
  const businessPool = questions.filter(q => q.domain === 'Ambiente de Negócios');

  const selectedReal = [
    ...shuffle(peoplePool).slice(0, peopleCount),
    ...shuffle(processPool).slice(0, processCount),
    ...shuffle(businessPool).slice(0, businessCount)
  ];

  // Select 5 pre-test questions from the remaining pool
  const usedIds = new Set(selectedReal.map(q => q.id));
  const remainingPool = questions.filter(q => !usedIds.has(q.id));
  const selectedPreTest = shuffle(remainingPool).slice(0, preTestCount);

  const finalQuestions = shuffle([...selectedReal, ...selectedPreTest]);
  const preTestIds = selectedPreTest.map(q => q.id);

  return {
    mode: 'exame',
    questionCount: count,
    currentQuestionIndex: 0,
    score: 0,
    answers: [],
    xp: 0,
    level: 1,
    lives: 3,
    isFinished: false,
    startTime: Date.now(),
    questions: finalQuestions,
    preTestIds,
    timeRemaining: totalTimeMinutes * 60,
    totalTime: totalTimeMinutes * 60,
  };
}

function shuffle<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

export function saveExamProgress(state: QuizState) {
  if (typeof window === 'undefined') return;
  localStorage.setItem('pmp_exam_progress', JSON.stringify(state));
}

export function loadExamProgress(): QuizState | null {
  if (typeof window === 'undefined') return null;
  const data = localStorage.getItem('pmp_exam_progress');
  return data ? JSON.parse(data) : null;
}

export function clearExamProgress() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem('pmp_exam_progress');
}

export function calculateExamResults(state: QuizState): ExamResults {
  const realQuestions = state.questions.filter(q => !state.preTestIds?.includes(q.id));
  let score = 0;
  
  const domainPerformance: Record<Domain, { score: number; total: number }> = {
    'Pessoas': { score: 0, total: 0 },
    'Processos': { score: 0, total: 0 },
    'Ambiente de Negócios': { score: 0, total: 0 }
  };

  realQuestions.forEach(q => {
    const answer = state.answers.find(a => a.questionId === q.id);
    const isCorrect = answer?.isCorrect || false;
    if (isCorrect) score++;
    
    domainPerformance[q.domain].total++;
    if (isCorrect) domainPerformance[q.domain].score++;
  });

  return {
    score,
    total: realQuestions.length,
    domainPerformance
  };
}

export interface ExamResults {
  score: number;
  total: number;
  domainPerformance: Record<Domain, { score: number; total: number }>;
}
