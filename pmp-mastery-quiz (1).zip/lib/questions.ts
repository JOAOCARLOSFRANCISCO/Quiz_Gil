export type Domain = 'Pessoas' | 'Processos' | 'Ambiente de Negócios';

export interface Question {
  id: number;
  text: string;
  options: {
    id: string;
    text: string;
  }[];
  correctOption: string;
  explanation: string;
  category: string;
  domain: Domain;
  difficulty: 'easy' | 'medium' | 'hard';
}

export const questions: Question[] = [
  {
    id: 1,
    text: "Os sistemas de gestão de mudanças lidam com alterações nos processos do projeto, referências, etc. Os sistemas de gestão de configuração lidam com as alterações nas características do produto. Qual das seguintes afirmações é verdadeira relativamente a sistemas de gestão de mudanças e de configuração?",
    options: [
      { id: "a", text: "O sistema de gestão de configuração é um subconjunto do sistema de gestão de alterações" },
      { id: "b", text: "O sistema de gestão de alterações é um subconjunto do sistema de gestão de configuração" },
      { id: "c", text: "O sistema de gestão de configuração e o sistema de gestão de alterações não estão relacionados entre si" },
      { id: "d", text: "Nenhuma das anteriores" }
    ],
    correctOption: "b",
    explanation: "O sistema de gestão de configuração lida com a alteração no âmbito do produto e, por isso, o sistema de gestão de alterações é um subconjunto do sistema de gestão de configuração.",
    category: "Integração",
    domain: "Processos",
    difficulty: "medium"
  },
  {
    id: 2,
    text: "O projeto está 25% concluído, gastaste 21% do teu orçamento e estás ligeiramente atrasado em relação ao prazo. Começas a recolher informações como as datas de início e fim das atividades agendadas, número de pedidos de alteração, número de defeitos, custos reais, durações reais, etc. Estes são exemplos de:",
    options: [
      { id: "a", text: "Medições de desempenho no trabalho" },
      { id: "b", text: "Dados de desempenho no trabalho" },
      { id: "c", text: "Informação sobre desempenho no trabalho" },
      { id: "d", text: "Parâmetros" }
    ],
    correctOption: "b",
    explanation: "Os dados de desempenho no trabalho são dados brutos baseados em observações e medições do estado do projeto; por exemplo, custo real, duração do tempo, percentagem do trabalho concluído, número de defeitos, etc.",
    category: "Monitoramento e Controle",
    domain: "Processos",
    difficulty: "easy"
  },
  {
    id: 3,
    text: "O estatuto do projeto foi assinado e você está preparando uma descrição detalhada do seu projeto e do produto. Os requisitos finais são identificados, os limites dos produtos são definidos e você delineou o que está incluído e o que está excluído. Depois de concluir este processo, qual dos seguintes documentos não irá atualizar a seguir?",
    options: [
      { id: "a", text: "Registo de emissões" },
      { id: "b", text: "Registo de partes interessadas" },
      { id: "c", text: "Documentação de requisitos" },
      { id: "d", text: "Matriz de rastreabilidade dos requisitos" }
    ],
    correctOption: "a",
    explanation: "O processo de definir o âmbito resulta na atualização do registo das partes interessadas, documentação de requisitos e matriz de rastreabilidade. O registro de emissões (issues log) geralmente não é atualizado imediatamente após a definição do escopo.",
    category: "Escopo",
    domain: "Processos",
    difficulty: "medium"
  },
  {
    id: 4,
    text: "Você está visitando os stakeholders do projeto e perguntando sobre as suas necessidades e expectativas. Também já fez muitos workshops e sessões de brainstorming com eles. Qual é este processo?",
    options: [
      { id: "a", text: "Identificar as partes interessadas" },
      { id: "b", text: "Coletar requisitos" },
      { id: "c", text: "Definir o escopo" },
      { id: "d", text: "Controlar o escopo" }
    ],
    correctOption: "b",
    explanation: "Coletar requisitos é o processo de determinar, documentar e gerenciar as necessidades e requisitos das partes interessadas para atingir os objetivos do projeto.",
    category: "Escopo",
    domain: "Processos",
    difficulty: "easy"
  },
  {
    id: 5,
    text: "A duração do projeto é de dois anos. Passou um ano, apenas 40% do trabalho foi concluído, mas o plano indicava que 50% deveria estar pronto. Você gastou 60% do orçamento. Qual é o índice de custo-desempenho (CPI) do projeto?",
    options: [
      { id: "a", text: "1.25" },
      { id: "b", text: "1.5" },
      { id: "c", text: "0.8" },
      { id: "d", text: "0.67" }
    ],
    correctOption: "d",
    explanation: "CPI = EV / AC. Se assumirmos orçamento total X, EV = 0.4X e AC = 0.6X. CPI = 0.4 / 0.6 = 0.67.",
    category: "Custos",
    domain: "Processos",
    difficulty: "hard"
  },
  {
    id: 6,
    text: "Um entregável está 90% concluído. Uma equipe de auditores verifica se o processo está sendo seguido. Quando o entregável está prestes a ser concluído, você o verifica e mede todas as dimensões para encontrar possíveis defeitos. Que processo é este?",
    options: [
      { id: "a", text: "Controlar a Qualidade" },
      { id: "b", text: "Gerenciar a Qualidade" },
      { id: "c", text: "Planejar o Gerenciamento da Qualidade" },
      { id: "d", text: "Controlar o Escopo" }
    ],
    correctOption: "a",
    explanation: "Controlar a Qualidade é o processo de monitorar e registrar os resultados da execução das atividades de qualidade para avaliar o desempenho e recomendar as mudanças necessárias.",
    category: "Qualidade",
    domain: "Processos",
    difficulty: "medium"
  },
  {
    id: 7,
    text: "Um stakeholder influente pergunta por que um entregável está demorando e quem é o responsável. Você encaminha um documento que mostra a relação entre o entregável e a pessoa responsável. Que documento é este?",
    options: [
      { id: "a", text: "Enunciado do Escopo" },
      { id: "b", text: "Registro de Partes Interessadas" },
      { id: "c", text: "Matriz RACI" },
      { id: "d", text: "Registro de Emissões" }
    ],
    correctOption: "c",
    explanation: "A matriz RACI (Responsável, Autoridade, Consultado e Informado) é um tipo comum de matriz de atribuição de responsabilidades (RAM) usada para definir papéis e responsabilidades.",
    category: "Recursos",
    domain: "Pessoas",
    difficulty: "easy"
  },
  {
    id: 8,
    text: "Você assinou um contrato para fornecer pessoal por 50 USD/hora, mais reembolso de custos incorridos e uma taxa fixa de 25.000 USD. Que tipo de contrato é este?",
    options: [
      { id: "a", text: "FPIF (Preço Fixo com Incentivo)" },
      { id: "b", text: "T&M (Tempo e Material)" },
      { id: "c", text: "CPAF (Custo Acrescido de Taxa de Prêmio)" },
      { id: "d", text: "CPFF (Custo Acrescido de Taxa Fixa)" }
    ],
    correctOption: "b",
    explanation: "O contrato de Tempo e Material (T&M) é um tipo híbrido que contém aspectos de contratos de custo reembolsável e de preço fixo.",
    category: "Aquisições",
    domain: "Processos",
    difficulty: "medium"
  },
  {
    id: 9,
    text: "Qual capítulo do Código de Ética e Conduta Profissional do PMI diz: 'Somos verdadeiros nas nossas comunicações e na nossa conduta.'?",
    options: [
      { id: "a", text: "Responsabilidade" },
      { id: "b", text: "Respeito" },
      { id: "c", text: "Justiça" },
      { id: "d", text: "Honestidade" }
    ],
    correctOption: "d",
    explanation: "O valor da Honestidade no Código de Ética do PMI foca em ser verdadeiro em comunicações e conduta.",
    category: "Ética",
    domain: "Pessoas",
    difficulty: "easy"
  },
  {
    id: 10,
    text: "Você está em uma reunião e nota que alguns membros estão dominando outros, e alguns ficam em silêncio. Que ferramenta garante uma contribuição justa e elimina a dominância?",
    options: [
      { id: "a", text: "Grupo de Foco" },
      { id: "b", text: "Workshop Facilitado" },
      { id: "c", text: "Brainstorming" },
      { id: "d", text: "Técnica Delphi" }
    ],
    correctOption: "d",
    explanation: "A Técnica Delphi ajuda a obter consenso entre especialistas de forma anônima, evitando que uma única pessoa domine a discussão.",
    category: "Comunicações",
    domain: "Pessoas",
    difficulty: "medium"
  },
  {
    id: 11,
    text: "Uma organização está avaliando se deve iniciar um projeto baseado no retorno sobre o investimento (ROI) e alinhamento estratégico. Qual domínio de prática do PMP isso representa?",
    options: [
      { id: "a", text: "Pessoas" },
      { id: "b", text: "Processos" },
      { id: "c", text: "Ambiente de Negócios" },
      { id: "d", text: "Gestão de Riscos" }
    ],
    correctOption: "c",
    explanation: "O domínio Ambiente de Negócios foca no alinhamento organizacional, conformidade e entrega de valor de negócio.",
    category: "Estratégia",
    domain: "Ambiente de Negócios",
    difficulty: "medium"
  }
];
